In the original version of Go In Practice, we wrote an entire chapter on
dependency management. But during the course of writing the book, Go 1.5
was released, which (in our opinion) solves most of the problems we were
dealing with when we first wrote the book.
