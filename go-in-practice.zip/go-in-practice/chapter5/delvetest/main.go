package main

import (
	"fmt"
	"time"
)

func main() {
	time.Sleep(2 * time.Second)
	fmt.Println("OH HAI!")
}
