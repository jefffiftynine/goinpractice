package hello

func Hello() string {
	return "hello"
}
