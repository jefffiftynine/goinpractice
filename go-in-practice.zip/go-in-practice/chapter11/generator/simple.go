//go:generate echo hello
package main

func main() {
	println("Goodbyte")
}
