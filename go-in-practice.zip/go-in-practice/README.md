# Go in Practice

The source code repository for Manning Publications [Go in Practice](http://manning.com/butcher/).

The source here is uncommented. To understand the source you'll need the
commentary that goes along with it in the book.