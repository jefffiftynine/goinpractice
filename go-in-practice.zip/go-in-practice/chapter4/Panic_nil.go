package main

func main() {
	panic(nill)
}